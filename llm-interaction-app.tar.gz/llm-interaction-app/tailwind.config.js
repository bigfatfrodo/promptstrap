module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}', './public/index.html'],
  theme: {
    extend: {
      colors: {
        'bright-blue': '#007BFF',
        'dark-teal': '#004D4D',
        'aqua-orange': '#FF7F50',
      },
    },
  },
  plugins: [],
};
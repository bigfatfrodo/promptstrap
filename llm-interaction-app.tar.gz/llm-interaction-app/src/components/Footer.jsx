import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-4">
      <div className="container mx-auto text-center">
        <p className="mb-2">&copy; {new Date().getFullYear()} LLM Interaction App</p>
        <ul className="flex justify-center space-x-4">
          <li><a href="/terms_of_service" className="hover:underline">Terms of Service</a></li>
          <li><a href="/privacy_policy" className="hover:underline">Privacy Policy</a></li>
          <li><a href="/contact" className="hover:underline">Contact Information</a></li>
        </ul>
      </div>
    </footer>
  );
};

export default Footer;
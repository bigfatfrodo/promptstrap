import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-dark-teal p-4 text-center">
      <div className="text-white">
        <a href="/terms_of_service" className="hover:underline">Terms of Service</a> | 
        <a href="/privacy_policy" className="hover:underline">Privacy Policy</a> | 
        <a href="/contact" className="hover:underline">Contact Information</a>
      </div>
    </footer>
  );
};

export default Footer;
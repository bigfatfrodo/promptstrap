import React, { useState } from 'react';

const InputForm = () => {
  const [inputValue, setInputValue] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Handle the input submission logic here
    console.log(inputValue);
    setInputValue(''); // Clear the input after submission
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col items-center p-4">
      <input
        type="text"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        className="border border-gray-300 rounded p-2 mb-4 text-black bg-white"
        placeholder="Type your prompt here..."
        style={{ color: '#000000' }}
      />
      <button type="submit" className="bg-aqua-orange text-white py-2 px-4 rounded hover:bg-green-600">
        Submit
      </button>
    </form>
  );
};

export default InputForm;
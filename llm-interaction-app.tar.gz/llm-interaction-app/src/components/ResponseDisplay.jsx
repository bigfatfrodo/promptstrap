import React from 'react';

const ResponseDisplay = ({ messages }) => {
  return (
    <div className="p-4 bg-white rounded shadow-md">
      <h2 className="text-lg font-bold mb-2">Responses:</h2>
      <ul className="list-disc pl-5">
        {messages.map((message, index) => (
          <li key={index} className="text-black mb-1">{message}</li>
        ))}
      </ul>
    </div>
  );
};

export default ResponseDisplay;
import React from 'react';

const ChatOutput = ({ messages }) => {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md max-h-96 overflow-y-auto">
      {messages.length === 0 ? (
        <p className="text-gray-500">No messages yet.</p>
      ) : (
        <ul className="space-y-2">
          {messages.map((msg, index) => (
            <li key={index} className="p-2 bg-gray-100 rounded-lg">
              {msg}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default ChatOutput;
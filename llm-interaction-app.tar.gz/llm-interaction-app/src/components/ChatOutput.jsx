import React from 'react';

const ChatOutput = ({ messages }) => {
  return (
    <div className="p-4 bg-gray-100 rounded-lg shadow-md max-h-96 overflow-y-auto">
      {messages.map((msg, index) => (
        <div key={index} className="mb-2 p-2 bg-white rounded-lg shadow">
          <p className="text-gray-800">{msg}</p>
        </div>
      ))}
    </div>
  );
};

export default ChatOutput;
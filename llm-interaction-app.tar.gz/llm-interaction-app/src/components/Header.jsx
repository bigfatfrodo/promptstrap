import React from 'react';
import citySkylineImage from '../assets/city_skyline.jpeg';

const Header = () => {
  return (
    <header className="relative w-full h-64 bg-black">
      <img src={citySkylineImage} alt="Futuristic city skyline at night with neon lights" className="absolute inset-0 object-cover w-full h-full" />
      <div className="absolute inset-0 bg-black opacity-50" />
      <h1 className="relative text-white text-4xl font-bold text-center pt-20">Welcome to the LLM Interaction App</h1>
    </header>
  );
};

export default Header;
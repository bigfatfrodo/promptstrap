import React from 'react';

const Header = () => {
  return (
    <header className="relative w-full h-64 bg-black">
      <img 
        src="/assets/city_skyline.jpeg" 
        alt="Futuristic city skyline at night with neon lights" 
        className="absolute inset-0 object-cover w-full h-full opacity-70"
      />
      <div className="absolute inset-0 flex items-center justify-center">
        <h1 className="text-4xl font-bold text-white">Welcome to the LLM Interaction App</h1>
      </div>
    </header>
  );
};

export default Header;
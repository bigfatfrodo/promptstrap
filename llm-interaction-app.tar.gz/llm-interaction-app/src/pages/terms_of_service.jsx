import React from 'react';

const TermsOfService = () => {
  return (
    <div className="p-6 bg-white text-black">
      <h1 className="text-2xl font-bold mb-4">Terms of Service</h1>
      <p className="mb-4">Welcome to the LLM Interaction App. By using our service, you agree to the following terms and conditions.</p>
      <h2 className="text-xl font-semibold mb-2">1. Acceptance of Terms</h2>
      <p className="mb-4">By accessing or using our application, you agree to be bound by these terms. If you do not agree, please do not use our service.</p>
      <h2 className="text-xl font-semibold mb-2">2. Changes to Terms</h2>
      <p className="mb-4">We may update these terms from time to time. We will notify you of any changes by posting the new terms on this page.</p>
      <h2 className="text-xl font-semibold mb-2">3. User Responsibilities</h2>
      <p className="mb-4">You are responsible for your use of the application and for any content you submit. You agree not to use the service for any unlawful purposes.</p>
      <h2 className="text-xl font-semibold mb-2">4. Limitation of Liability</h2>
      <p className="mb-4">We are not liable for any damages arising from your use of the application. Use the service at your own risk.</p>
      <h2 className="text-xl font-semibold mb-2">5. Contact Us</h2>
      <p>If you have any questions about these terms, please contact us.</p>
    </div>
  );
};

export default TermsOfService;
import React from 'react';

const TermsOfService = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Terms of Service</h1>
      <p className="mb-4">Last updated: [Date]</p>
      <h2 className="text-2xl font-semibold mb-2">1. Acceptance of Terms</h2>
      <p className="mb-4">By accessing or using our application, you agree to be bound by these Terms of Service and our Privacy Policy.</p>
      <h2 className="text-2xl font-semibold mb-2">2. Changes to Terms</h2>
      <p className="mb-4">We may modify these terms at any time. Your continued use of the application after any changes constitutes your acceptance of the new terms.</p>
      <h2 className="text-2xl font-semibold mb-2">3. User Responsibilities</h2>
      <p className="mb-4">You are responsible for your use of the application and for any content you provide. You agree not to use the application for any unlawful purpose.</p>
      <h2 className="text-2xl font-semibold mb-2">4. Limitation of Liability</h2>
      <p className="mb-4">In no event shall we be liable for any indirect, incidental, or consequential damages arising from your use of the application.</p>
      <h2 className="text-2xl font-semibold mb-2">5. Governing Law</h2>
      <p className="mb-4">These terms shall be governed by the laws of [Your State/Country].</p>
      <h2 className="text-2xl font-semibold mb-2">6. Contact Us</h2>
      <p>If you have any questions about these Terms, please contact us at [Your Contact Information].</p>
    </div>
  );
};

export default TermsOfService;
import React from 'react';

const Contact = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Contact Information</h1>
      <p className="mb-4">If you have any questions or need further information, please reach out to us:</p>
      <h2 className="text-2xl font-semibold mb-2">Email</h2>
      <p className="mb-4">support@llminteractionapp.com</p>
      <h2 className="text-2xl font-semibold mb-2">Phone</h2>
      <p className="mb-4">(123) 456-7890</p>
      <h2 className="text-2xl font-semibold mb-2">Address</h2>
      <p className="mb-4">123 LLM St, Language City, LC 12345</p>
    </div>
  );
};

export default Contact;
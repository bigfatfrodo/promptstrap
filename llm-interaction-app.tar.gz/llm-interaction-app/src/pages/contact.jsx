import React from 'react';

const Contact = () => {
  return (
    <div className="p-6 bg-white text-black">
      <h1 className="text-2xl font-bold mb-4">Contact Information</h1>
      <p className="mb-4">If you have any questions or need further information, please reach out to us:</p>
      <h2 className="text-xl font-semibold mb-2">Email:</h2>
      <p className="mb-4">support@llminteractionapp.com</p>
      <h2 className="text-xl font-semibold mb-2">Phone:</h2>
      <p className="mb-4">(123) 456-7890</p>
      <h2 className="text-xl font-semibold mb-2">Address:</h2>
      <p className="mb-4">123 LLM St, AI City, CA 12345</p>
    </div>
  );
};

export default Contact;
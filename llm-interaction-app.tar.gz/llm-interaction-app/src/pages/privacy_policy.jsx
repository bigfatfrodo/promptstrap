import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="p-6 bg-white text-black">
      <h1 className="text-2xl font-bold mb-4">Privacy Policy</h1>
      <p className="mb-4">Your privacy is important to us. This privacy policy explains how we collect, use, and protect your information when you use our application.</p>
      <h2 className="text-xl font-semibold mb-2">1. Information We Collect</h2>
      <p className="mb-4">We may collect personal information such as your name, email address, and any other information you provide when using our service.</p>
      <h2 className="text-xl font-semibold mb-2">2. How We Use Your Information</h2>
      <p className="mb-4">We use your information to provide and improve our services, communicate with you, and comply with legal obligations.</p>
      <h2 className="text-xl font-semibold mb-2">3. Data Security</h2>
      <p className="mb-4">We take reasonable measures to protect your information from unauthorized access, use, or disclosure.</p>
      <h2 className="text-xl font-semibold mb-2">4. Changes to This Privacy Policy</h2>
      <p className="mb-4">We may update this privacy policy from time to time. We will notify you of any changes by posting the new policy on this page.</p>
      <h2 className="text-xl font-semibold mb-2">5. Contact Us</h2>
      <p>If you have any questions about this privacy policy, please contact us.</p>
    </div>
  );
};

export default PrivacyPolicy;
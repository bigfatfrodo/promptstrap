import React from 'react';

const PrivacyPolicy = () => {
  return (
    <div className="max-w-4xl mx-auto p-6">
      <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
      <p className="mb-4">Last updated: [Date]</p>
      <h2 className="text-2xl font-semibold mb-2">1. Introduction</h2>
      <p className="mb-4">This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our application.</p>
      <h2 className="text-2xl font-semibold mb-2">2. Information We Collect</h2>
      <p className="mb-4">We may collect information about you in a variety of ways, including personal data, usage data, and cookies.</p>
      <h2 className="text-2xl font-semibold mb-2">3. Use of Your Information</h2>
      <p className="mb-4">We may use the information we collect from you to provide, maintain, and improve our services.</p>
      <h2 className="text-2xl font-semibold mb-2">4. Disclosure of Your Information</h2>
      <p className="mb-4">We may share your information with third parties in certain circumstances, such as with service providers or for legal reasons.</p>
      <h2 className="text-2xl font-semibold mb-2">5. Security of Your Information</h2>
      <p className="mb-4">We use administrative, technical, and physical security measures to help protect your personal information.</p>
      <h2 className="text-2xl font-semibold mb-2">6. Your Rights</h2>
      <p className="mb-4">You have the right to access, correct, or delete your personal information, and to withdraw consent at any time.</p>
      <h2 className="text-2xl font-semibold mb-2">7. Changes to This Privacy Policy</h2>
      <p className="mb-4">We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.</p>
      <h2 className="text-2xl font-semibold mb-2">8. Contact Us</h2>
      <p>If you have any questions about this Privacy Policy, please contact us at [Your Contact Information].</p>
    </div>
  );
};

export default PrivacyPolicy;
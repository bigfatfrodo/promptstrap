import axios from 'axios';

const API_URL = 'https://api.example.com/language-model';

export const fetchResponse = async (prompt) => {
  try {
    const response = await axios.post(API_URL, { prompt });
    return response.data;
  } catch (error) {
    console.error('Error fetching response from the language model:', error);
    throw error;
  }
};

export const setApiUrl = (url) => {
  API_URL = url;
};
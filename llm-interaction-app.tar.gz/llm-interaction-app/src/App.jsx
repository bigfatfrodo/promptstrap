import React from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import InputForm from './components/InputForm';
import ResponseDisplay from './components/ResponseDisplay';

const App = () => {
  const [messages, setMessages] = React.useState([]);

  const handleNewMessage = (newMessage) => {
    setMessages((prevMessages) => [...prevMessages, newMessage]);
  };

  return (
    <div className="flex flex-col min-h-screen bg-bright-blue">
      <Header />
      <main className="flex-grow p-4">
        <InputForm onNewMessage={handleNewMessage} />
        <ResponseDisplay messages={messages} />
      </main>
      <Footer />
    </div>
  );
};

export default App;
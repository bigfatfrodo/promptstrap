import React, { useState } from 'react';
import Header from './components/Header';
import Footer from './components/Footer';
import ChatInput from './components/ChatInput';
import ChatOutput from './components/ChatOutput';

const App = () => {
  const [messages, setMessages] = useState([]);

  const handleSend = (input) => {
    // Here you would typically send the input to the language model and get a response.
    // For now, we'll just echo the input back as a message.
    setMessages((prevMessages) => [...prevMessages, input]);
  };

  return (
    <div className="flex flex-col h-screen">
      <Header />
      <main className="flex-grow p-4">
        <ChatOutput messages={messages} />
        <ChatInput onSend={handleSend} />
      </main>
      <Footer />
    </div>
  );
};

export default App;
import React, { useCallback, useRef } from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';
import InputBar from '../components/InputBar';
import ChatWindow, { ChatWindowHandle } from '../components/ChatWindow';

const Home: React.FC = () => {
  const chatRef = useRef<ChatWindowHandle>(null);

  const handleSend = useCallback((text: string) => {
    chatRef.current?.sendMessage(text);
  }, []);

  return (
    <div className="flex flex-col min-h-screen dark:bg-[#000812] text-neutral-200">
      {/* Header */}
      <Header />

      {/* Main chat area */}
      <main className="flex-1 flex flex-col gap-4 p-4 max-w-4xl w-full mx-auto">
        {/* Chat window grows to fill available space */}
        <ChatWindow ref={chatRef} />

        {/* Input bar */}
        <InputBar onSend={handleSend} />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Home;

import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import Footer from '../components/Footer';

const Contact: React.FC = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Header */}
      <Header />

      {/* Main Content */}
      <main className="flex-1 max-w-3xl mx-auto px-4 py-8 text-neutral-200">
        <h2 className="text-3xl font-bold mb-6 text-[#FF6B35]">Contact Us</h2>

        <p className="mb-4">
          We would love to hear from you! Whether you have a question about features, pricing, need a demo, or anything else, our team is ready to answer all your
          questions.
        </p>

        <p className="mb-4">
          Reach us directly via email at{' '}
          <Link
            to="mailto:contact@neonchat.app"
            className="text-[#1E90FF] hover:underline focus:outline-none focus:ring-2 focus:ring-[#1E90FF]"
          >
            contact@neonchat.app
          </Link>
          . We aim to respond within 24 hours.
        </p>

        <p className="mb-4">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis
          nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
        </p>
        <p className="mb-4">
          Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt
          in culpa qui officia deserunt mollit anim id est laborum.
        </p>
      </main>

      {/* Footer */}
      <Footer />
    </div>
  );
};

export default Contact;

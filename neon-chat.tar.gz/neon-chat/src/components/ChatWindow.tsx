import React, {
  forwardRef,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from 'react';
import ChatBubble from './ChatBubble';
import { getRandomLorem } from '../utils/loremGenerator';

interface Message {
  author: 'user' | 'bot';
  text: string;
}

export interface ChatWindowHandle {
  /**
   * Adds a user message to the chat and schedules a bot reply.
   */
  sendMessage: (text: string) => void;
}

const ChatWindow = forwardRef<ChatWindowHandle>((_, ref) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);
  const replyTimeout = useRef<ReturnType<typeof setTimeout> | null>(null);

  /**
   * Scrolls to the top of the container (since we use flex-col-reverse).
   */
  const scrollToLatest = () => {
    if (containerRef.current) {
      containerRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  /**
   * Handles sending a user prompt and queuing the bot response.
   */
  const sendMessage = (text: string) => {
    if (!text.trim()) return;

    // Add user message
    setMessages((prev) => [{ author: 'user', text }, ...prev]);

    // Schedule bot response
    replyTimeout.current = setTimeout(() => {
      const botReply: Message = { author: 'bot', text: getRandomLorem(1) };
      setMessages((prev) => [botReply, ...prev]);
    }, 500);
  };

  // Expose imperative handle to parent components (e.g., Home -> InputBar)
  useImperativeHandle(ref, () => ({ sendMessage }), []);

  // Auto-scroll whenever messages change
  useEffect(scrollToLatest, [messages]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (replyTimeout.current) clearTimeout(replyTimeout.current);
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className="flex-1 overflow-y-auto border border-white/20 rounded-md shadow p-4 bg-white/5 backdrop-blur-sm"
    >
      <div className="flex flex-col-reverse">
        {messages.map((msg, idx) => (
          <ChatBubble
            key={idx}
            message={msg.text}
            isUser={msg.author === 'user'}
          />
        ))}
      </div>
    </div>
  );
});

ChatWindow.displayName = 'ChatWindow';

export default ChatWindow;

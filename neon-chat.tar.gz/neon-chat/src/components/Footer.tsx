import React from 'react';
import { Link } from 'react-router-dom';

const Footer: React.FC = () => {
  return (
    <footer className="flex justify-center gap-4 py-4 text-sm bg-[#014F86] text-[#1E90FF]">
      <Link to="/terms" className="hover:underline focus:outline-none focus:ring-2 focus:ring-[#1E90FF]">
        Terms of Service
      </Link>
      <Link to="/privacy" className="hover:underline focus:outline-none focus:ring-2 focus:ring-[#1E90FF]">
        Privacy Policy
      </Link>
      <Link to="/contact" className="hover:underline focus:outline-none focus:ring-2 focus:ring-[#1E90FF]">
        Contact
      </Link>
    </footer>
  );
};

export default Footer;

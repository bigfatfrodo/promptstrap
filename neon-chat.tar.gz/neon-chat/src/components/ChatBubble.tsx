import React from 'react';

interface ChatBubbleProps {
  message: string;
  isUser: boolean;
}

const ChatBubble: React.FC<ChatBubbleProps> = ({ message, isUser }) => {
  return (
    <div
      className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} my-2`}
    >
      <div
        className={`px-4 py-2 text-sm text-white rounded-full border shadow max-w-[80%] ${
          isUser ? 'bg-[#1E90FF]' : 'bg-[#014F86]'
        }`}
      >
        {message}
      </div>
    </div>
  );
};

export default ChatBubble;

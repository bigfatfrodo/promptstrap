import React from 'react';
import skylineImage from '../assets/skyline.jpeg';

const Header: React.FC = () => {
  return (
    <header className="w-full relative">
      {/* Background Image */}
      <img
        src={skylineImage}
        alt="Futuristic city skyline at night with neon lights"
        className="w-full h-48 md:h-64 object-cover select-none"
      />

      {/* Dark Teal translucent overlay */}
      <div className="absolute inset-0 bg-[#014F86]/70 flex items-center justify-center">
        <h1 className="text-4xl md:text-5xl font-extrabold text-[#FF6B35] drop-shadow-lg">
          NeonChat
        </h1>
      </div>
    </header>
  );
};

export default Header;

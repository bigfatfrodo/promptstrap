// src/utils/loremGenerator.ts

/**
 * Returns a slice of lorem ipsum text consisting of the requested number of paragraphs.
 * The slice starts at a random index in the lorem array and wraps around if necessary,
 * ensuring the result is always contiguous.
 *
 * @param paragraphs - Number of paragraphs to include (defaults to 1). If the value
 *                     is less than or equal to 0, an empty string is returned.
 * @returns A string containing the generated lorem ipsum paragraphs separated by blank lines.
 */
export function getRandomLorem(paragraphs: number = 1): string {
  if (paragraphs <= 0) return '';

  const LOREM_PARAGRAPHS: readonly string[] = [
    'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
    'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
    'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.',
    'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
    'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.',
    'Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.',
    'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos.',
    'Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit.',
    'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque.',
    'Et harum quidem rerum facilis est et expedita distinctio.',
    'Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus.',
    'Omnis voluptas assumenda est, omnis dolor repellendus.',
    'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae.',
    'Itaque earum rerum hic tenetur a sapiente delectus, ut aut reiciendis voluptatibus maiores alias consequatur aut perferendis doloribus asperiores repellat.',
    'Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur.'
  ];

  const total = LOREM_PARAGRAPHS.length;
  const startIndex = Math.floor(Math.random() * total);
  const result: string[] = [];

  for (let i = 0; i < paragraphs; i++) {
    result.push(LOREM_PARAGRAPHS[(startIndex + i) % total]);
  }

  return result.join('\n\n');
}

import { type Config } from 'tailwindcss';

/** @type {Config} */
const config = {
  content: [
    './index.html',
    './src/**/*.{js,ts,jsx,tsx}'
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brightBlue: '#1E90FF',
        darkTeal: '#014F86',
        aquaOrange: '#FF6B35'
      }
    }
  },
  plugins: []
};

export default config;
